In a true autonomous drug discovery platform, **none of the QSAR agents described earlier should be responsible for creating millions of compounds**. That responsibility belongs to a separate set of **Molecular Design Agents** that sit upstream of the QSAR Scientist architecture.

A mature architecture typically looks like:

```text
Molecular Design Layer
        │
        ▼
Virtual Screening Layer
        │
        ▼
QSAR Scientist Layer
        │
        ▼
ADMET/Toxicology Layer
        │
        ▼
Portfolio Optimization Layer
```

# 1. Molecular Generation Agent

This is the primary "compound creation" agent.

## Purpose

Generate novel molecules that satisfy target objectives.

## Inputs

```json
{
  "target": "EGFR",
  "desired_activity": ">100nM",
  "max_mw": 500,
  "max_logp": 4,
  "toxicity_constraints": {},
  "known_actives": []
}
```

## Technologies

* Reinforcement Learning
* Diffusion Models
* Graph Neural Networks
* Molecular Transformers

Examples:

* MegaMolBART
* MolGX
* REINVENT
* DrugEx

## Output

```text
1,000,000 candidate molecules
```

represented as:

```text
SMILES
SELFIES
Molecular Graphs
```

---

# 2. Scaffold Exploration Agent

Instead of generating molecules from scratch, this agent expands known chemotypes.

## Example

Starting scaffold:

```text
Quinoline
```

Generate:

```text
500,000 variants
```

by modifying:

* Side chains
* Ring substitutions
* Functional groups

This is often more useful than unconstrained generation.

---

# 3. Bioisostere Replacement Agent

Acts like a medicinal chemist.

Given:

```text
Lead compound
```

it systematically substitutes:

```text
OH → NH2
Phenyl → Pyridine
Amide → Urea
```

while attempting to preserve activity.

This can easily generate:

```text
100,000+
analogs
```

around a known lead.

---

# 4. Reaction-Based Enumeration Agent

This is how many pharmaceutical companies generate millions of realistic compounds.

Instead of inventing molecules, it uses:

* Known reactions
* Commercial building blocks
* Synthesis rules

Example:

```text
10,000 amines
×
5,000 acids
```

creates:

```text
50 million
virtual amides
```

that are actually synthesizable.

This is one of the highest-value approaches in industry.

---

# 5. Library Expansion Agent

Uses known databases such as:

* PubChem
* ChEMBL
* ZINC

to find compounds similar to active molecules.

This often expands:

```text
100 actives
```

into

```text
1-10 million neighbors
```

without inventing new chemistry.

---

# 6. Evolutionary Design Agent

Acts like natural selection.

## Process

Generation 0

```text
1000 molecules
```

↓

QSAR scoring

↓

Keep top 10%

↓

Mutate

↓

Cross-over

↓

Generate new population

↓

Repeat

After 100 generations:

```text
Millions of compounds explored
```

while only storing the best candidates.

---

# 7. Multi-Objective Optimization Agent

This is usually the "master designer."

It optimizes simultaneously for:

```text
Potency
Selectivity
Solubility
Permeability
Toxicity
Synthetic Accessibility
Cost
Patentability
```

The objective is not:

```text
Highest activity
```

but:

```text
Best overall drug candidate
```

---

# Typical Industrial Pipeline

A modern autonomous platform might work like:

```text
Known Actives
        │
        ▼
Scaffold Expansion Agent
        │
        ▼
5 Million Molecules
        │
        ▼
QSAR Screening Agent
        │
        ▼
500,000 Survive
        │
        ▼
Docking Agent
        │
        ▼
50,000 Survive
        │
        ▼
ADMET Agent
        │
        ▼
5,000 Survive
        │
        ▼
Molecular Dynamics Agent
        │
        ▼
500 Survive
        │
        ▼
Synthetic Accessibility Agent
        │
        ▼
100 Survive
        │
        ▼
Portfolio Optimization Agent
        │
        ▼
Top 10 Molecules
```

# Agent Responsible for "Millions of Compounds"

In most real-world systems, the compounds come from a combination of:

| Agent                      | Typical Output |
| -------------------------- | -------------- |
| Molecular Generation Agent | 1M–100M        |
| Reaction Enumeration Agent | 10M–1B         |
| Scaffold Expansion Agent   | 100K–10M       |
| Evolutionary Design Agent  | 1M–50M         |
| Library Expansion Agent    | 1M–100M        |
| Bioisostere Agent          | 100K–5M        |

For a startup or research platform, the highest ROI architecture is usually:

```text
Reaction Enumeration Agent
        +
Scaffold Expansion Agent
        +
QSAR Scientist
        +
Multi-Objective Optimization Agent
```

because it produces **millions of chemically realistic, synthesizable compounds** rather than millions of chemically invalid molecules, which is a common problem with purely generative approaches.

