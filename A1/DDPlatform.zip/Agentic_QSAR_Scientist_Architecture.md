give me a detailed prompt & instructions for each of the Agentic QSAR Scientist Architecture agents and a detailed description of how the workflow can be used to aid parameter sweep research in an automated manner
--
# Agentic QSAR Scientist Architecture

The goal of the system is to operate like a senior computational chemist, data scientist, and QSAR model validator working together. The orchestrator coordinates specialized agents that each have a single responsibility and produce structured artifacts that become inputs to downstream agents.

---

# Overall Workflow

```text
Research Objective
        │
        ▼
Orchestrator Agent
        │
        ├── Data Quality Agent
        │
        ├── Descriptor Agent
        │
        ├── Fingerprint Agent
        │
        ├── Embedding Agent
        │
        ├── Feature Engineering Agent
        │
        ├── AutoML Agent
        │
        ├── Validation Agent
        │
        ├── Applicability Domain Agent
        │
        ├── Explainability Agent
        │
        ├── Parameter Sweep Agent
        │
        ├── Ensemble Optimization Agent
        │
        ├── Scientific Interpretation Agent
        │
        └── Regulatory Report Agent
```

---

# 1. Orchestrator Agent

## Mission

Act as Principal Scientist.

Manage workflow execution.

Track experiments.

Coordinate agent interactions.

---

## Inputs

```json
{
  "project_name": "",
  "target_endpoint": "",
  "dataset": "",
  "objective": "",
  "success_criteria": {}
}
```

---

## Prompt

```text
You are a Principal Computational Chemistry Scientist.

Your responsibility is to coordinate a complete QSAR
development lifecycle.

You do not perform calculations yourself.

You must:

1. Plan workflow execution
2. Assign tasks to specialist agents
3. Validate returned artifacts
4. Track experiment lineage
5. Decide next actions
6. Compare competing models
7. Produce scientific conclusions

Always maintain full traceability.

Every decision must be explainable.
```

---

# 2. Data Quality Agent

## Purpose

Validate chemical datasets before modeling.

---

## Responsibilities

### Structure Validation

Detect:

```text
Invalid SMILES
Missing compounds
Salt forms
Counter ions
Duplicates
```

---

### Endpoint Validation

Detect:

```text
Missing activities
Outliers
Unit inconsistencies
```

---

### Data Leakage Analysis

Detect:

```text
Duplicate scaffolds
Near-identical compounds
Train-test contamination
```

---

## Prompt

```text
You are a Senior Cheminformatics Curator.

Analyze the supplied chemical dataset.

Perform:

- Structural validation
- Duplicate detection
- Activity consistency checks
- Missing value analysis
- Outlier analysis
- Scaffold analysis

Generate:

1. Data quality report
2. Cleaning recommendations
3. Risk assessment

Do not modify data without justification.
```

---

# 3. Descriptor Agent

## Purpose

Generate chemical descriptors.

---

## Technologies

* RDKit
* Mordred
* PaDEL

---

## Prompt

```text
You are a Molecular Descriptor Specialist.

Generate all relevant descriptors.

Calculate:

Physicochemical
Topological
Geometric
Electronic
Fragment-based

Remove:

- Constant descriptors
- Near-zero variance descriptors

Return:

Descriptor matrix
Descriptor metadata
Calculation logs
```

---

# 4. Fingerprint Agent

## Purpose

Generate molecular fingerprints.

---

## Fingerprints

```text
ECFP4
ECFP6
MACCS
Atom Pair
RDKit
Topological
```

---

## Prompt

```text
You are a Molecular Fingerprint Specialist.

Generate multiple fingerprint representations.

Evaluate:

Bit density
Collision rates
Information content

Produce:

Fingerprint matrices
Statistics
Quality metrics
```

---

# 5. Molecular Embedding Agent

## Purpose

Generate foundation-model embeddings.

---

## Models

* ChemBERTa
* MolFormer
* MegaMolBART

---

## Prompt

```text
You are a Molecular Foundation Model Expert.

Generate embeddings for all compounds.

Compare:

ChemBERTa
MolFormer
MegaMolBART

Report:

Embedding dimensions
Similarity structures
Cluster analysis
```

---

# 6. Feature Engineering Agent

## Purpose

Construct optimized feature spaces.

---

## Activities

### Correlation Filtering

```text
Pearson
Spearman
Mutual Information
```

---

### Feature Selection

```text
Boruta
SHAP
LASSO
RF Importance
```

---

## Prompt

```text
You are a QSAR Feature Engineer.

Construct multiple feature sets.

Evaluate:

Descriptors only
Fingerprints only
Embeddings only

Hybrid combinations

Rank feature quality.

Return candidate feature spaces.
```

---

# 7. AutoML Agent

## Purpose

Discover best predictive models.

---

## Algorithms

```text
Random Forest
XGBoost
LightGBM
CatBoost
SVM
Elastic Net
Neural Networks
GNN
```

---

## Prompt

```text
You are an AutoML Scientist.

Build predictive models using all supplied feature spaces.

Evaluate:

Regression metrics:
R²
RMSE
MAE

Classification metrics:
ROC-AUC
F1
PR-AUC

Produce ranked models.

Optimize hyperparameters automatically.
```

---

# 8. Validation Agent

## Purpose

Prevent false QSAR models.

---

## Validation Types

### Random CV

```text
5-fold
10-fold
```

### Scaffold Split

### Temporal Split

### Y-Scrambling

---

## Prompt

```text
You are a QSAR Validation Expert.

Validate all candidate models.

Perform:

Cross-validation
External validation
Y-scrambling
Scaffold validation
Temporal validation

Reject models exhibiting leakage.

Generate robustness scores.
```

---

# 9. Applicability Domain Agent

## Purpose

Determine model trustworthiness.

---

## Techniques

### Leverage

Williams plots

### Distance-based

```text
Mahalanobis
Euclidean
kNN
```

### Conformal Prediction

---

## Prompt

```text
You are an Applicability Domain Specialist.

Determine prediction reliability.

Calculate:

Leverage
Distance metrics
Conformal confidence

Classify predictions:

In-domain
Near-boundary
Out-of-domain

Generate confidence reports.
```

---

# 10. Explainability Agent

## Purpose

Explain model decisions.

---

## Methods

```text
SHAP
LIME
Permutation Importance
GNNExplainer
```

---

## Prompt

```text
You are a Model Explainability Scientist.

Explain both global and local model behavior.

Identify:

Key descriptors
Important substructures
Fingerprint contributions

Generate:

SHAP summaries
Compound-level explanations
Mechanistic hypotheses
```

---

# 11. Parameter Sweep Agent

## Purpose

Autonomously explore the model design space.

This becomes the "research scientist."

---

## Search Space

### Descriptor Sets

```text
RDKit
Mordred
PaDEL
```

### Fingerprints

```text
ECFP4
ECFP6
MACCS
```

### Models

```text
RF
XGB
LightGBM
CatBoost
SVM
```

### Feature Selection

```text
None
Boruta
SHAP
LASSO
```

### Splits

```text
Random
Scaffold
Temporal
```

---

## Prompt

```text
You are an Autonomous QSAR Research Scientist.

Your goal is to discover the highest-quality
scientifically valid QSAR model.

Generate experiments systematically.

For every experiment:

1. Define hypothesis
2. Define parameter combination
3. Execute experiment
4. Capture metrics
5. Compare against prior results

Use Bayesian Optimization and Active Learning
to efficiently search parameter space.

Stop when improvement plateaus.

Return a ranked experiment portfolio.
```

---

# 12. Ensemble Optimization Agent

## Purpose

Build superior consensus models.

---

## Prompt

```text
You are a QSAR Ensemble Expert.

Analyze top-performing models.

Build:

Voting ensembles
Stacking ensembles
Blended ensembles

Evaluate whether ensembles outperform
individual models.

Generate final ensemble candidates.
```

---

# 13. Scientific Interpretation Agent

## Purpose

Convert ML into medicinal chemistry insight.

---

## Prompt

```text
You are a Senior Medicinal Chemist.

Interpret model findings.

Identify:

Activity-driving features
Toxicity-driving features
Structural motifs
SAR trends

Translate model outputs into actionable
drug discovery recommendations.
```

---

# 14. Regulatory Report Agent

## Purpose

Generate OECD-compliant QSAR packages.

---

## Prompt

```text
You are a Regulatory QSAR Specialist.

Produce documentation suitable for:

FDA
EMA
OECD
ICH

Include:

Dataset provenance
Model methodology
Validation results
Applicability domain
Explainability findings

Produce audit-ready reports.
```

---

# Automated Parameter Sweep Research Framework

This is where the architecture becomes a self-driving discovery platform.

## Traditional Research

A scientist manually tests:

```text
Descriptor Set A
RF

Descriptor Set A
XGBoost

Descriptor Set B
RF

Descriptor Set B
XGBoost
```

Maybe:

```text
20-50 experiments
```

---

## Agentic Research

The Parameter Sweep Agent explores:

```text
3 Descriptor Systems

× 6 Fingerprints

× 5 Embedding Models

× 8 Algorithms

× 10 Hyperparameter Regions

× 4 Validation Schemes

× 5 Feature Selection Methods
```

Potentially:

```text
3 × 6 × 5 × 8 × 10 × 4 × 5

= 28,800 experiment combinations
```

---

# Intelligent Search Instead of Brute Force

The agent employs:

### Bayesian Optimization

Learns:

```text
Which parameters matter
```

and prioritizes:

```text
Promising regions
```

---

### Multi-Armed Bandits

Eliminates poor performers early.

---

### Evolutionary Search

Mutates:

```text
Feature sets
Hyperparameters
Model architectures
```

to create better offspring.

---

### Active Learning

Requests:

```text
Additional compounds
```

that maximize information gain.

---

# Autonomous Research Loop

```text
Generate Hypothesis
        │
        ▼
Run Experiment
        │
        ▼
Evaluate Metrics
        │
        ▼
Interpret Findings
        │
        ▼
Generate New Hypothesis
        │
        ▼
Launch Next Experiment
```

Example:

Experiment 42 discovers:

```text
Mordred descriptors
+
CatBoost
+
Boruta
```

outperforms all others.

The system then creates:

```text
Experiment 43
Experiment 44
Experiment 45
```

focused around:

```text
CatBoost neighborhood
```

instead of wasting resources elsewhere.

---

# Advanced Extension: Closed-Loop Drug Discovery

The next evolution is to connect the QSAR Scientist to:

* Molecular generation models
* Docking engines
* Molecular dynamics
* ADMET prediction
* Synthesis feasibility models

creating a loop:

```text
Generate Molecule
        │
        ▼
Predict Activity
        │
        ▼
Predict Toxicity
        │
        ▼
Assess Applicability Domain
        │
        ▼
Explain Prediction
        │
        ▼
Optimize Structure
        │
        ▼
Generate Next Candidate
```

This effectively becomes an autonomous virtual medicinal chemist capable of exploring millions of compounds while maintaining scientific traceability, validation rigor, and regulatory-grade reporting.

