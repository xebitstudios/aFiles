A mature autonomous drug discovery platform can operate at several levels of sophistication depending on what the user provides. The platform's inputs and outputs vary accordingly.

# Level 1: Target-Based Drug Discovery

This is the most common scenario.

## Input

```json
{
  "project_name": "EGFR Inhibitor Discovery",
  "target_protein": "EGFR",
  "disease_area": "Non-Small Cell Lung Cancer",
  "objective": "Discover novel EGFR inhibitors",
  "known_actives": [
    "Gefitinib",
    "Erlotinib",
    "Osimertinib"
  ]
}
```

### User Provides

* Target protein
* Disease indication
* Known drugs
* Desired constraints

Example:

```text
Find compounds that inhibit EGFR.

Requirements:
- IC50 < 100 nM
- MW < 500
- Oral bioavailability > 30%
- Low hERG risk
```

---

## Output

```json
{
  "generated_compounds": 5000000,
  "screened_compounds": 5000000,
  "top_candidates": 100,
  "recommended_for_synthesis": 10
}
```

Detailed outputs:

```text
10 Lead Candidates

Predicted Potency
Docking Score
ADMET Profile
Synthetic Route
Patent Similarity
Confidence Score
```

---

# Level 2: Existing Dataset-Based QSAR

This is common in pharma and biotech.

## Input

A bioactivity dataset.

Example:

```csv
compound_id,smiles,ic50
CMP001,CCNCC1=CC=CC=C1,10
CMP002,CNCC2=CC=CC=C2,30
CMP003,CCCNC3=CC=CC=C3,100
```

Or:

```text
ChEMBL dataset
Internal assay results
HTS campaign output
```

---

## Platform Activities

```text
Validate data
Generate descriptors
Generate fingerprints
Generate embeddings
Run AutoML
Validate models
Determine applicability domain
Explain results
```

---

## Output

### Best QSAR Model

```json
{
  "algorithm": "CatBoost",
  "r2": 0.82,
  "rmse": 0.31,
  "cv_score": 0.79
}
```

### Explainability Report

```text
Top Features

TPSA
LogP
ECFP Bit 113
Hydrogen Bond Donors
```

### Applicability Domain

```text
92% compounds in domain
8% out of domain
```

---

# Level 3: Lead Optimization

Starting from one or more lead compounds.

## Input

```json
{
  "lead_compounds": [
    "CCN(CC)CCOC1=CC=CC=C1"
  ],
  "target_property": {
    "activity": "increase",
    "toxicity": "decrease",
    "solubility": "increase"
  }
}
```

---

## Platform Activities

```text
Generate analogs
Perform bioisosteric replacements
Enumerate reaction products
Predict activity
Optimize ADMET
Select best candidates
```

---

## Output

```text
Original Lead

Activity:
50 nM

Optimized Candidate

Predicted Activity:
5 nM

Improved Solubility:
+35%

Reduced Toxicity:
-50%
```

---

# Level 4: Library Screening

The user already has millions of compounds.

## Input

```json
{
  "compound_library": "10M compounds",
  "target": "KRAS G12D"
}
```

---

## Platform Activities

```text
Descriptor generation
QSAR screening
Docking
ADMET filtering
Synthetic accessibility scoring
```

---

## Output

```text
10,000,000 Input

500,000 Pass QSAR

50,000 Pass Docking

5,000 Pass ADMET

500 Pass SA

25 Final Candidates
```

---

# Level 5: Multi-Objective Discovery Campaign

A pharmaceutical portfolio use case.

## Input

```json
{
  "target": "PCSK9",
  "constraints": {
    "potency": ">95%",
    "toxicity": "minimal",
    "bioavailability": ">40%",
    "cost": "<$500/g"
  }
}
```

---

## Output

### Pareto Frontier

The platform does not return a single winner.

It returns:

```text
Candidate A

Best potency

Candidate B

Best safety

Candidate C

Best manufacturability

Candidate D

Best overall balance
```

---

# Inputs to Individual Layers

## Molecular Design Layer

Input:

```json
{
  "target": "EGFR",
  "known_actives": [],
  "constraints": {}
}
```

Output:

```json
{
  "generated_molecules": [
    "SMILES1",
    "SMILES2",
    "SMILES3"
  ]
}
```

Typically:

```text
100K – 100M molecules
```

---

## Virtual Screening Layer

Input:

```json
{
  "molecules": [...],
  "target_structure": "PDB"
}
```

Output:

```json
{
  "predictions": [
    {
      "activity": 0.92,
      "dock_score": -11.4,
      "toxicity": "Low"
    }
  ]
}
```

---

## QSAR Scientist Layer

Input:

```json
{
  "training_dataset": "...",
  "endpoint": "IC50"
}
```

Output:

```json
{
  "best_model": {},
  "validation_report": {},
  "explainability_report": {},
  "applicability_domain_report": {}
}
```

---

## Portfolio Optimization Layer

Input:

```json
{
  "candidate_set": [...]
}
```

Output:

```json
{
  "top_10_for_synthesis": [...],
  "top_5_for_animal_studies": [...],
  "backup_candidates": [...]
}
```

---

# Final Deliverables Produced by the Entire Platform

A typical autonomous discovery campaign would produce:

### Scientific Deliverables

* Target analysis report
* QSAR models
* SAR analysis
* Molecular clusters
* Explainability reports
* Applicability domain reports

### Chemistry Deliverables

* Millions of generated compounds
* Filtered candidate libraries
* Lead optimization recommendations
* Synthetic routes
* Retrosynthesis plans

### AI Deliverables

* AutoML experiment history
* Parameter sweep results
* Hyperparameter optimization results
* Ensemble model reports

### Decision Deliverables

* Ranked candidate portfolio
* Top compounds for synthesis
* Risk assessments
* Confidence scores
* Go/No-Go recommendations

### Regulatory Deliverables

* OECD QSAR package
* Audit trail
* Model cards
* Reproducibility package
* Validation documentation

In practice, the most valuable output is not the millions of generated molecules. It is the **final ranked portfolio of perhaps 10–100 high-confidence compounds**, each accompanied by potency predictions, ADMET assessments, synthetic routes, uncertainty estimates, explainability reports, and experimental recommendations. This allows medicinal chemists and project teams to focus laboratory resources on the candidates with the highest probability of success.

