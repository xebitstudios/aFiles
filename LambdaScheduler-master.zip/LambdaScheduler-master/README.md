# Lambda Scheduler 

### In this project, I have created one Lambda function which is invoked after every 1 minutes. 

https://www.youtube.com/c/AjayWadhara/videos



![Presentation1](https://user-images.githubusercontent.com/68158756/180669557-87d4a6a4-a78e-4fe4-8a35-1c3b144d56c0.png)
