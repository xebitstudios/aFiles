import * as cdk from 'aws-cdk-lib';
import { Construct } from 'constructs';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as apigateway from 'aws-cdk-lib/aws-apigateway';
// import * as sqs from 'aws-cdk-lib/aws-sqs';

export class CrudApiStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props);

    const table = new dynamodb.Table(this, 'ItemsTable', {
      partitionKey: { name: 'id', type: dynamodb.AttributeType.STRING },
      removalPolicy: cdk.RemovalPolicy.DESTROY,
    });

    // Create Lambda function
    const crudLambda = new lambda.Function(this, 'CrudLambda', {
      runtime: lambda.Runtime.NODEJS_16_X,
      handler: 'crud.handler',
      code: lambda.Code.fromAsset('lambda'),
      environment: {
        TABLE_NAME: table.tableName,
      },
    });

    // Grant the Lambda function read/write permissions to our table
    table.grantWriteData(crudLambda);

    // creata an API Gateway REST API
    const api = new apigateway.RestApi(this, 'ItemsApi', {
      restApiName: 'Items Service',
      description: 'This service serves items.',
    });

    // Create API Gateway resource and method for creating an item
    const items = api.root.addResource('items');
    items.addMethod('POST', new apigateway.LambdaIntegration(crudLambda));
    items.addMethod('GET', new apigateway.LambdaIntegration(crudLambda));

    // Create Lambda function for reading items
    const item = items.addResource('{id}');
    item.addMethod('GET', new apigateway.LambdaIntegration(crudLambda));
    item.addMethod('PUT', new apigateway.LambdaIntegration(crudLambda));
    item.addMethod('DELETE', new apigateway.LambdaIntegration(crudLambda));    
  }
}
