import { APIGatewayProxyHandler } from 'aws-lambda';
import { DynamoDB } from 'aws-sdk';

const dynamoDb = new DynamoDB.DocumentClient();
const TABLE_NAME = process.env.TABLE_NAME || '';

export const handler: APIGatewayProxyHandler = async (event: { httpMethod: any; pathParameters: any; body: any; }) => {
  const { httpMethod, pathParameters, body } = event;

  switch (httpMethod) {
    case 'POST': {
      const item = JSON.parse(body || '{}');
      const params = {
        TableName: TABLE_NAME,
        Item: item,
      };
      await dynamoDb.put(params).promise();
      return {
        statusCode: 201,
        body: JSON.stringify({ message: 'Item created', item }),
      };
    }
    case 'GET': {
      if (pathParameters && pathParameters.id) {
        const params = {
          TableName: TABLE_NAME,
          Key: {
            id: pathParameters.id,
          },
        };
        const result = await dynamoDb.get(params).promise();
        if (result.Item) {
          return {
            statusCode: 200,
            body: JSON.stringify(result.Item),
          };
        }
        return {
          statusCode: 404,
          body: JSON.stringify({ message: 'Item not found' }),
        };
      } else {
        const params = {
          TableName: TABLE_NAME,
        };
        const result = await dynamoDb.scan(params).promise();
        return {
          statusCode: 200,
          body: JSON.stringify(result.Items),
        };
      }
    }
    case 'PUT': {
      if (pathParameters && pathParameters.id) {
        const item = JSON.parse(body || '{}');
        const params = {
          TableName: TABLE_NAME,
          Key: {
            id: pathParameters.id,
          },
          UpdateExpression: 'set name = :name',
          ExpressionAttributeValues: {
            ':name': item.name,
          },
          ReturnValues: 'UPDATED_NEW',
        };
        const result = await dynamoDb.update(params).promise();
        return {
          statusCode: 200,
          body: JSON.stringify(result.Attributes),
        };
      }
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Invalid request' }),
      };
    }
    case 'DELETE': {
      if (pathParameters && pathParameters.id) {
        const params = {
          TableName: TABLE_NAME,
          Key: {
            id: pathParameters.id,
          },
        };
        await dynamoDb.delete(params).promise();
        return {
          statusCode: 200,
          body: JSON.stringify({ message: 'Item deleted' }),
        };
      }
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Invalid request' }),
      };
    }
    default:
      return {
        statusCode: 405,
        body: 'Method Not Allowed',
      };
  }
}