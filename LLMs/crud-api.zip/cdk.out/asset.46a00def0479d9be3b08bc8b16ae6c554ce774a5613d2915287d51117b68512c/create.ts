import { DynamoDB } from 'aws-sdk';

const db = new DynamoDB.DocumentClient();
const TABLE_NAME = process.env.TABLE_NAME || '';

export const handler = async (event: any = {}): Promise<any> => {
  const body = JSON.parse(event.body);
  const item = {
    id: body.id,
    name: body.name,
    description: body.description,
  };

  await db.put({
    TableName: TABLE_NAME,
    Item: item,
  }).promise();

  return {
    statusCode: 201,
    body: JSON.stringify(item),
  }
}