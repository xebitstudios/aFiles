import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';

export const routes: Routes = [
  // { path: '', redirectTo: 'login', pathMatch: 'full' }, // Default route
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  // { path: 'about', component: AboutComponent },
  // { path: 'about', component: AboutComponent },
  // { path: 'profile/:id', component: ProfileComponent },
  // { path: 'contact', component: ContactComponent },
  // { path: '**', component: PageNotFoundComponent } // Wildcard route for 404 page
];
