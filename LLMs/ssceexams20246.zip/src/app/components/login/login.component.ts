import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';  // <-- Import FormsModule

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    FormsModule
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  username: string;
  password: string;

  constructor() {
    this.username = '';
    this.password = '';
  }

  login() {
    if (this.username === 'admin' && this.password === 'password') {
      alert('Login successful!'); // Replace with actual login logic
    } else {
      alert('Invalid username or password.'); // Replace with actual error handling
    }

    // Reset the form after submission (optional)
    this.username = '';
    this.password = '';
  }
}
