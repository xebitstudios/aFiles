import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Router } from '@angular/router';
import { MockheaderComponent } from './partials/mockheader/mockheader.component';
import { MockfooterComponent } from './partials/mockfooter/mockfooter.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, MockheaderComponent, MockfooterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  
constructor(private router: Router) {
  this.navigateToLogin();
}

  title = 'ssceexams20246';

  navigateToLogin() {
    this.router.navigate(['login']); // Navigate to /login route
  }
  
}

