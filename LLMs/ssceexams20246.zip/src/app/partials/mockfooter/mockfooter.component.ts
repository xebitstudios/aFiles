import { Component } from '@angular/core';

@Component({
  selector: 'app-mockfooter',
  standalone: true,
  imports: [],
  templateUrl: './mockfooter.component.html',
  styleUrl: './mockfooter.component.css'
})
export class MockfooterComponent {

}
