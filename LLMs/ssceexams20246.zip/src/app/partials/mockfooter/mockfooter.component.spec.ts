import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MockfooterComponent } from './mockfooter.component';

describe('MockfooterComponent', () => {
  let component: MockfooterComponent;
  let fixture: ComponentFixture<MockfooterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MockfooterComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MockfooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
