import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RecentexamComponent } from './recentexam.component';

describe('RecentexamComponent', () => {
  let component: RecentexamComponent;
  let fixture: ComponentFixture<RecentexamComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RecentexamComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(RecentexamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
