import { Component } from '@angular/core';

@Component({
  selector: 'app-recentexam',
  standalone: true,
  imports: [],
  templateUrl: './recentexam.component.html',
  styleUrl: './recentexam.component.css'
})
export class RecentexamComponent {

}
