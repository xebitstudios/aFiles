import { Component } from '@angular/core';

@Component({
  selector: 'app-toprow',
  standalone: true,
  imports: [],
  templateUrl: './toprow.component.html',
  styleUrl: './toprow.component.css'
})
export class ToprowComponent {

}
