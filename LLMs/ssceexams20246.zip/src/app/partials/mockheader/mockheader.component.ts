import { Component } from '@angular/core';

@Component({
  selector: 'app-mockheader',
  standalone: true,
  imports: [],
  templateUrl: './mockheader.component.html',
  styleUrl: './mockheader.component.css'
})
export class MockheaderComponent {
  title = 'mockheader';
}
