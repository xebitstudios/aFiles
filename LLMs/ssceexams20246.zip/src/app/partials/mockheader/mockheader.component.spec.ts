import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MockheaderComponent } from './mockheader.component';

describe('MockheaderComponent', () => {
  let component: MockheaderComponent;
  let fixture: ComponentFixture<MockheaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MockheaderComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MockheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
