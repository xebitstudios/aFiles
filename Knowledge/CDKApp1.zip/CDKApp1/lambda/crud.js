const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();
const TABLE_NAME = process.env.TABLE_NAME;

exports.handler = async (event) => {
  const httpMethod = event.httpMethod;
  let response;

  switch (httpMethod) {
    case 'GET':
      if (event.pathParameters && event.pathParameters.id) {
        response = await getItem(event.pathParameters.id);
      } else {
        response = await getAllItems();
      }
      break;
    case 'POST':
      response = await createItem(JSON.parse(event.body));
      break;
    case 'PUT':
      response = await updateItem(event.pathParameters.id, JSON.parse(event.body));
      break;
    case 'DELETE':
      response = await deleteItem(event.pathParameters.id);
      break;
    default:
      response = {
        statusCode: 405,
        body: JSON.stringify({ message: 'Method Not Allowed' }),
      };
      break;
  }

  return response;
};

const getAllItems = async () => {
  const params = {
    TableName: TABLE_NAME,
  };
  const data = await dynamo.scan(params).promise();
  return { statusCode: 200, body: JSON.stringify(data.Items) };
};

const getItem = async (id) => {
  const params = {
    TableName: TABLE_NAME,
    Key: { id },
  };
  const data = await dynamo.get(params).promise();
  return { statusCode: 200, body: JSON.stringify(data.Item) };
};

const createItem = async (item) => {
  item.id = item.id || Date.now().toString();
  const params = {
    TableName: TABLE_NAME,
    Item: item,
  };
  await dynamo.put(params).promise();
  return { statusCode: 201, body: JSON.stringify(item) };
};

const updateItem = async (id, updates) => {
  const params = {
    TableName: TABLE_NAME,
    Key: { id },
    UpdateExpression: 'set #n = :n, #d = :d',
    ExpressionAttributeNames: { '#n': 'name', '#d': 'description' },
    ExpressionAttributeValues: {
      ':n': updates.name,
      ':d': updates.description,
    },
    ReturnValues: 'ALL_NEW',
  };
  const data = await dynamo.update(params).promise();
  return { statusCode: 200, body: JSON.stringify(data.Attributes) };
};

const deleteItem = async (id) => {
  const params = {
    TableName: TABLE_NAME,
    Key: { id },
  };
  await dynamo.delete(params).promise();
  return { statusCode: 200, body: JSON.stringify({ message: 'Item deleted' }) };
};
