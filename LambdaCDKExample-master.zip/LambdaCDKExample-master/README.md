# LambdaCDKExample

### This is a sample CDK project to create AWS Lambda function. I have covered this under complete tutorial on my YouTube channnel (link below).

https://www.youtube.com/c/AjayWadhara/videos
