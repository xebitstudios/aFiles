// Investment Status Types
export type InvestmentStatus = 'Not Started' | 'Open' | 'Closing' | 'Ongoing' | 'Closed';

// Partner Types
export type PartnerType = 'Farm Partner' | 'Monetary Partner' | 'Monitoring Partner';

// Investment Interface
export interface Investment {
  id: string;
  name: string;
  shortName: string;
  location: string;
  duration: string;
  durationMonths: number;
  status: InvestmentStatus;
  description: string;
  coverImage: string;
  cropType: string;
  acreage?: number;
  greenhouse?: string;
  
  // Financial Details
  totalInvestmentAmount: number;
  minInvestmentAmount: number;
  
  // Coverage Details
  coverage: {
    staffSalaries: boolean;
    plantFeed: boolean;
    pesticideHerbicides: boolean;
    greenhouseMaterials: boolean;
    operatingExpenses: boolean;
    transportExpense: boolean;
  };
  
  // Partner Requirements
  partnerRequirements: {
    farmPartner: string[];
    monetaryPartner: string[];
    monitoringPartner: string[];
  };
  
  // Timeline
  timeline: {
    startDate: string;
    closingDate: string;
    expectedHarvestDate: string;
    terminationDate: string;
  };
  
  // Progress (for ongoing investments)
  progress?: {
    currentMonth: number;
    totalMonths: number;
    percentageComplete: number;
  };
  
  // Returns
  expectedReturns?: {
    minReturn: number;
    maxReturn: number;
    unit: 'percentage' | 'naira';
  };
  
  // Additional Info
  updates: Update[];
  documents: Document[];
}

export interface Update {
  id: string;
  date: string;
  title: string;
  content: string;
  type: 'general' | 'harvest' | 'financial' | 'milestone';
}

export interface Document {
  id: string;
  name: string;
  type: 'pdf' | 'doc' | 'image';
  size: string;
  url: string;
}

// Partner Interface
export interface Partner {
  id: string;
  name: string;
  email: string;
  phone: string;
  type: PartnerType;
  joinDate: string;
  
  // Investments this partner is involved in
  investments: PartnerInvestment[];
  
  // For monitoring partners
  visitSchedule?: {
    frequency: string;
    lastVisit?: string;
    nextVisit?: string;
    totalVisits: number;
  };
  
  // Transport claims
  transportClaims?: TransportClaim[];
}

export interface PartnerInvestment {
  investmentId: string;
  investmentName: string;
  amountInvested: number;
  percentageShare: number;
  joinDate: string;
  status: InvestmentStatus;
  returnsReceived: number;
  expectedReturns: number;
}

export interface TransportClaim {
  id: string;
  date: string;
  investmentId: string;
  investmentName: string;
  amount: number;
  status: 'pending' | 'approved' | 'paid';
  receiptUrl?: string;
}

// Filter Types
export interface InvestmentFilters {
  status: InvestmentStatus | 'all';
  partnerType: PartnerType | 'all';
  duration: 'short' | 'medium' | 'long' | 'all';
  searchQuery: string;
}

// Contact Form
export interface ContactForm {
  name: string;
  email: string;
  phone: string;
  partnerType: PartnerType | '';
  message: string;
}
