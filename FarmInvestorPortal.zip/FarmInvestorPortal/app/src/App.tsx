import { useState, useMemo } from 'react';
import { motion, AnimatePresence, type Variants } from 'framer-motion';
import { 
  Sprout, 
  TrendingUp, 
  Users, 
  Calendar, 
  MapPin, 
  DollarSign, 
  FileText, 
  ArrowRight,
  Filter,
  ChevronRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  Play,
  Pause,
  Search,
  Menu,
  Mail,
  Phone,
  MapPinned,
  Send
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { investments, currentPartner, getInvestmentById } from '@/data/investments';
import type { Investment, InvestmentStatus } from '@/types';

// Animation variants
const fadeInUp: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: { 
    opacity: 1, 
    y: 0, 
    transition: { duration: 0.5, ease: "easeOut" } 
  }
};

const staggerContainer: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.1
    }
  }
};

const cardHover: Variants = {
  rest: { scale: 1, y: 0 },
  hover: { 
    scale: 1.02, 
    y: -4,
    transition: { duration: 0.3, ease: "easeOut" }
  }
};

// Status badge component
const StatusBadge = ({ status }: { status: InvestmentStatus }) => {
  const statusClasses = {
    'Not Started': 'status-not-started',
    'Open': 'status-open',
    'Closing': 'status-closing',
    'Ongoing': 'status-ongoing',
    'Closed': 'status-closed',
  };
  
  const statusIcons = {
    'Not Started': <Clock className="w-3 h-3 mr-1" />,
    'Open': <CheckCircle2 className="w-3 h-3 mr-1" />,
    'Closing': <AlertCircle className="w-3 h-3 mr-1" />,
    'Ongoing': <Play className="w-3 h-3 mr-1" />,
    'Closed': <Pause className="w-3 h-3 mr-1" />,
  };
  
  return (
    <span className={`status-badge ${statusClasses[status]}`}>
      {statusIcons[status]}
      {status}
    </span>
  );
};

// Investment Card Component
const InvestmentCard = ({ 
  investment, 
  onClick,
  isPartnerInvestment = false 
}: { 
  investment: Investment; 
  onClick: () => void;
  isPartnerInvestment?: boolean;
}) => {
  const partnerInvestment = currentPartner.investments.find(
    pi => pi.investmentId === investment.id
  );
  
  return (
    <motion.div
      variants={cardHover}
      initial="rest"
      whileHover="hover"
    >
      <Card 
        className="cursor-pointer overflow-hidden card-shadow card-border transition-shadow duration-300 hover:shadow-xl"
        onClick={onClick}
      >
        <div className="relative h-48 overflow-hidden">
          <motion.img 
            src={investment.coverImage} 
            alt={investment.name}
            className="w-full h-full object-cover"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.5 }}
          />
          <div className="absolute top-3 left-3">
            <StatusBadge status={investment.status} />
          </div>
          {isPartnerInvestment && partnerInvestment && (
            <div className="absolute top-3 right-3">
              <Badge className="bg-[#D9A467] text-white">
                {partnerInvestment.percentageShare.toFixed(1)}% Share
              </Badge>
            </div>
          )}
        </div>
        
        <CardContent className="p-5">
          <div className="text-eyebrow text-[#6E6E6E] mb-2">
            {investment.cropType}
          </div>
          <h3 className="text-lg font-bold text-[#1A1A1A] mb-2 line-clamp-2">
            {investment.shortName}
          </h3>
          
          <div className="flex items-center text-sm text-[#6E6E6E] mb-3">
            <MapPin className="w-4 h-4 mr-1" />
            {investment.location}
          </div>
          
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center text-sm text-[#6E6E6E]">
              <Calendar className="w-4 h-4 mr-1" />
              {investment.duration}
            </div>
            <div className="flex items-center text-sm font-medium text-[#1A1A1A]">
              <DollarSign className="w-4 h-4 mr-0.5" />
              {(investment.totalInvestmentAmount / 1000000).toFixed(1)}M
            </div>
          </div>
          
          {investment.progress && (
            <div className="mt-4">
              <div className="flex justify-between text-xs mb-1">
                <span className="text-[#6E6E6E]">Progress</span>
                <span className="font-medium">{investment.progress.percentageComplete}%</span>
              </div>
              <Progress value={investment.progress.percentageComplete} className="h-2" />
              <div className="text-xs text-[#6E6E6E] mt-1">
                Month {investment.progress.currentMonth} of {investment.progress.totalMonths}
              </div>
            </div>
          )}
          
          {isPartnerInvestment && partnerInvestment && (
            <div className="mt-4 pt-4 border-t border-gray-100">
              <div className="flex justify-between items-center">
                <span className="text-sm text-[#6E6E6E]">Invested</span>
                <span className="font-semibold">₦{partnerInvestment.amountInvested.toLocaleString()}</span>
              </div>
              <div className="flex justify-between items-center mt-1">
                <span className="text-sm text-[#6E6E6E]">Expected Returns</span>
                <span className="font-semibold text-green-600">
                  ₦{partnerInvestment.expectedReturns.toLocaleString()}
                </span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
};

// Investment Detail Modal
const InvestmentDetailModal = ({ 
  investment, 
  isOpen, 
  onClose 
}: { 
  investment: Investment | null; 
  isOpen: boolean; 
  onClose: () => void;
}) => {
  if (!investment) return null;
  
  const partnerInvestment = currentPartner.investments.find(
    pi => pi.investmentId === investment.id
  );
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <DialogHeader>
            <div className="text-eyebrow text-[#6E6E6E] mb-2">
              {investment.cropType}
            </div>
            <DialogTitle className="text-2xl font-bold">
              {investment.name}
            </DialogTitle>
            <DialogDescription className="text-base">
              {investment.description}
            </DialogDescription>
          </DialogHeader>
          
          <div className="mt-6">
            <img 
              src={investment.coverImage} 
              alt={investment.name}
              className="w-full h-64 object-cover rounded-2xl"
            />
          </div>
          
          <motion.div 
            className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="bg-gray-50 p-4 rounded-xl">
              <div className="text-eyebrow text-[#6E6E6E] mb-1">Status</div>
              <StatusBadge status={investment.status} />
            </div>
            <div className="bg-gray-50 p-4 rounded-xl">
              <div className="text-eyebrow text-[#6E6E6E] mb-1">Duration</div>
              <div className="font-semibold">{investment.duration}</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-xl">
              <div className="text-eyebrow text-[#6E6E6E] mb-1">Total Investment</div>
              <div className="font-semibold">₦{investment.totalInvestmentAmount.toLocaleString()}</div>
            </div>
            <div className="bg-gray-50 p-4 rounded-xl">
              <div className="text-eyebrow text-[#6E6E6E] mb-1">Min. Investment</div>
              <div className="font-semibold">₦{investment.minInvestmentAmount.toLocaleString()}</div>
            </div>
          </motion.div>
          
          {investment.progress && (
            <motion.div 
              className="mt-6"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <h4 className="font-bold text-lg mb-3">Season Progress</h4>
              <div className="bg-gray-50 p-5 rounded-xl">
                <div className="flex justify-between mb-2">
                  <span className="text-[#6E6E6E]">Overall Progress</span>
                  <span className="font-bold">{investment.progress.percentageComplete}%</span>
                </div>
                <Progress value={investment.progress.percentageComplete} className="h-3" />
                <div className="flex justify-between mt-3 text-sm">
                  <span className="text-[#6E6E6E]">Month {investment.progress.currentMonth} of {investment.progress.totalMonths}</span>
                  <span className="text-[#6E6E6E]">Expected completion: {investment.timeline.terminationDate}</span>
                </div>
              </div>
            </motion.div>
          )}
          
          {partnerInvestment && (
            <motion.div 
              className="mt-6 bg-[#D9A467]/10 p-5 rounded-xl border border-[#D9A467]/20"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.25 }}
            >
              <h4 className="font-bold text-lg mb-4 flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-[#D9A467]" />
                Your Investment
              </h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div>
                  <div className="text-eyebrow text-[#6E6E6E] mb-1">Amount Invested</div>
                  <div className="font-bold text-lg">₦{partnerInvestment.amountInvested.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-eyebrow text-[#6E6E6E] mb-1">Your Share</div>
                  <div className="font-bold text-lg">{partnerInvestment.percentageShare.toFixed(2)}%</div>
                </div>
                <div>
                  <div className="text-eyebrow text-[#6E6E6E] mb-1">Expected Returns</div>
                  <div className="font-bold text-lg text-green-600">
                    ₦{partnerInvestment.expectedReturns.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-eyebrow text-[#6E6E6E] mb-1">Returns Received</div>
                  <div className="font-bold text-lg">
                    ₦{partnerInvestment.returnsReceived.toLocaleString()}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
          
          <motion.div 
            className="mt-6"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h4 className="font-bold text-lg mb-3">What's Covered</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {Object.entries(investment.coverage).map(([key, covered]) => (
                <div 
                  key={key}
                  className={`flex items-center p-3 rounded-xl ${covered ? 'bg-green-50' : 'bg-gray-50'}`}
                >
                  <div className={`w-2 h-2 rounded-full mr-2 ${covered ? 'bg-green-500' : 'bg-gray-300'}`} />
                  <span className={`text-sm ${covered ? 'text-green-700' : 'text-gray-400'}`}>
                    {key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
          
          <motion.div 
            className="mt-6"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.35 }}
          >
            <h4 className="font-bold text-lg mb-3">Partner Requirements</h4>
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-xl">
                <div className="font-semibold mb-2 flex items-center">
                  <Users className="w-4 h-4 mr-2" />
                  Farm Partner
                </div>
                <ul className="text-sm text-[#6E6E6E] space-y-1">
                  {investment.partnerRequirements.farmPartner.map((req, i) => (
                    <li key={i}>• {req}</li>
                  ))}
                </ul>
              </div>
              <div className="bg-gray-50 p-4 rounded-xl">
                <div className="font-semibold mb-2 flex items-center">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Monetary Partner
                </div>
                <ul className="text-sm text-[#6E6E6E] space-y-1">
                  {investment.partnerRequirements.monetaryPartner.map((req, i) => (
                    <li key={i}>• {req}</li>
                  ))}
                </ul>
              </div>
              <div className="bg-gray-50 p-4 rounded-xl">
                <div className="font-semibold mb-2 flex items-center">
                  <MapPinned className="w-4 h-4 mr-2" />
                  Monitoring Partner
                </div>
                <ul className="text-sm text-[#6E6E6E] space-y-1">
                  {investment.partnerRequirements.monitoringPartner.map((req, i) => (
                    <li key={i}>• {req}</li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
          
          {investment.updates.length > 0 && (
            <motion.div 
              className="mt-6"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <h4 className="font-bold text-lg mb-3">Latest Updates</h4>
              <div className="space-y-3">
                {investment.updates.map((update) => (
                  <div key={update.id} className="bg-gray-50 p-4 rounded-xl">
                    <div className="flex justify-between items-start mb-2">
                      <span className="font-semibold">{update.title}</span>
                      <span className="text-xs text-[#6E6E6E]">{update.date}</span>
                    </div>
                    <p className="text-sm text-[#6E6E6E]">{update.content}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
          
          {investment.documents.length > 0 && (
            <motion.div 
              className="mt-6"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.45 }}
            >
              <h4 className="font-bold text-lg mb-3">Documents</h4>
              <div className="space-y-2">
                {investment.documents.map((doc) => (
                  <a 
                    key={doc.id}
                    href={doc.url}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center">
                      <FileText className="w-5 h-5 mr-3 text-[#6E6E6E]" />
                      <span className="text-sm">{doc.name}</span>
                    </div>
                    <span className="text-xs text-[#6E6E6E]">{doc.size}</span>
                  </a>
                ))}
              </div>
            </motion.div>
          )}
        </motion.div>
      </DialogContent>
    </Dialog>
  );
};

// Contact Form Component
const ContactSection = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    partnerType: '',
    message: ''
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your interest! We will get back to you within 2 business days.');
    setFormData({ name: '', email: '', phone: '', partnerType: '', message: '' });
  };
  
  return (
    <section className="py-20 px-4 md:px-8 bg-[#11130E]">
      <div className="max-w-4xl mx-auto">
        <motion.div 
          className="bg-[#1A1A1A] rounded-[28px] p-8 md:p-12 border border-white/10"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Become a Partner
          </h2>
          <p className="text-gray-400 mb-8">
            Tell us how you'd like to participate. We'll send terms, timelines, and next steps.
          </p>
          
          <div className="grid md:grid-cols-3 gap-6 mb-10">
            <motion.div 
              className="flex items-center text-gray-400"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
            >
              <Mail className="w-5 h-5 mr-3 text-[#D9A467]" />
              hello@wilshirefarms.ng
            </motion.div>
            <motion.div 
              className="flex items-center text-gray-400"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              <Phone className="w-5 h-5 mr-3 text-[#D9A467]" />
              +234 801 234 5678
            </motion.div>
            <motion.div 
              className="flex items-center text-gray-400"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
            >
              <MapPin className="w-5 h-5 mr-3 text-[#D9A467]" />
              Oyo State, Nigeria
            </motion.div>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="grid md:grid-cols-2 gap-5">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
              >
                <Label className="text-gray-300 mb-2 block">Name</Label>
                <Input 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="bg-white/5 border-white/10 text-white"
                  placeholder="Your full name"
                  required
                />
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.15 }}
              >
                <Label className="text-gray-300 mb-2 block">Email</Label>
                <Input 
                  type="email"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="bg-white/5 border-white/10 text-white"
                  placeholder="your@email.com"
                  required
                />
              </motion.div>
            </div>
            
            <div className="grid md:grid-cols-2 gap-5">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.2 }}
              >
                <Label className="text-gray-300 mb-2 block">Phone</Label>
                <Input 
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="bg-white/5 border-white/10 text-white"
                  placeholder="+234..."
                />
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.25 }}
              >
                <Label className="text-gray-300 mb-2 block">Partner Type</Label>
                <Select 
                  value={formData.partnerType}
                  onValueChange={(value) => setFormData({...formData, partnerType: value})}
                >
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder="Select partner type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="farm">Farm Partner</SelectItem>
                    <SelectItem value="monetary">Monetary Partner</SelectItem>
                    <SelectItem value="monitoring">Monitoring Partner</SelectItem>
                  </SelectContent>
                </Select>
              </motion.div>
            </div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
            >
              <Label className="text-gray-300 mb-2 block">Message</Label>
              <Textarea 
                value={formData.message}
                onChange={(e) => setFormData({...formData, message: e.target.value})}
                className="bg-white/5 border-white/10 text-white min-h-[120px]"
                placeholder="Tell us about your interest..."
              />
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.35 }}
            >
              <Button 
                type="submit"
                className="bg-[#D9A467] hover:bg-[#C99455] text-white px-8 py-6 rounded-xl font-semibold"
              >
                <Send className="w-4 h-4 mr-2" />
                Send Request
              </Button>
            </motion.div>
          </form>
          
          <p className="text-gray-500 text-sm mt-6">
            Replies within 2 business days.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

// Main App Component
function App() {
  const [selectedInvestment, setSelectedInvestment] = useState<Investment | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState<InvestmentStatus | 'all'>('all');
  const [partnerFilter, setPartnerFilter] = useState<'all' | 'my-investments'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Filter investments
  const filteredInvestments = useMemo(() => {
    let filtered = investments;
    
    // Status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter(inv => inv.status === statusFilter);
    }
    
    // Partner filter
    if (partnerFilter === 'my-investments') {
      const myInvestmentIds = currentPartner.investments.map(pi => pi.investmentId);
      filtered = filtered.filter(inv => myInvestmentIds.includes(inv.id));
    }
    
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(inv => 
        inv.name.toLowerCase().includes(query) ||
        inv.cropType.toLowerCase().includes(query) ||
        inv.location.toLowerCase().includes(query)
      );
    }
    
    return filtered;
  }, [statusFilter, partnerFilter, searchQuery]);
  
  // Group investments by status
  const investmentsByStatus = useMemo(() => {
    const grouped: Record<InvestmentStatus, Investment[]> = {
      'Not Started': [],
      'Open': [],
      'Closing': [],
      'Ongoing': [],
      'Closed': []
    };
    filteredInvestments.forEach(inv => {
      grouped[inv.status].push(inv);
    });
    return grouped;
  }, [filteredInvestments]);
  
  const handleInvestmentClick = (investment: Investment) => {
    setSelectedInvestment(investment);
    setIsDetailOpen(true);
  };
  
  const statusOrder: InvestmentStatus[] = ['Ongoing', 'Open', 'Closing', 'Not Started', 'Closed'];
  
  return (
    <div className="min-h-screen bg-[#F4F1EC]">
      {/* Grain Overlay */}
      <div className="grain-overlay" />
      
      {/* Navigation */}
      <motion.nav 
        className="fixed top-0 left-0 right-0 z-50 bg-[#F4F1EC]/90 backdrop-blur-md border-b border-black/5"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <motion.div 
              className="flex items-center"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              <Sprout className="w-8 h-8 text-[#D9A467] mr-2" />
              <span className="font-bold text-lg md:text-xl tracking-tight">
                Wilshire Farms
              </span>
            </motion.div>
            
            {/* Desktop Nav */}
            <motion.div 
              className="hidden md:flex items-center space-x-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              <a href="#investments" className="text-sm font-medium hover:text-[#D9A467] transition-colors">
                Investments
              </a>
              <a href="#seasons" className="text-sm font-medium hover:text-[#D9A467] transition-colors">
                Seasons
              </a>
              <a href="#contact" className="text-sm font-medium hover:text-[#D9A467] transition-colors">
                Contact
              </a>
              <Button variant="outline" className="rounded-full border-[#D9A467] text-[#D9A467] hover:bg-[#D9A467] hover:text-white">
                Partner Login
              </Button>
            </motion.div>
            
            {/* Mobile Menu */}
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="w-6 h-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-[#F4F1EC]">
                <div className="flex flex-col space-y-6 mt-8">
                  <a 
                    href="#investments" 
                    className="text-lg font-medium"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Investments
                  </a>
                  <a 
                    href="#seasons" 
                    className="text-lg font-medium"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Seasons
                  </a>
                  <a 
                    href="#contact" 
                    className="text-lg font-medium"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Contact
                  </a>
                  <Button className="bg-[#D9A467] hover:bg-[#C99455] text-white rounded-full">
                    Partner Login
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </motion.nav>
      
      {/* Hero Section */}
      <section className="pt-24 md:pt-32 pb-12 px-4 md:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Hero Image Card */}
            <motion.div 
              className="lg:col-span-2 relative rounded-[28px] overflow-hidden card-shadow h-[400px] md:h-[500px]"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              <img 
                src="/images/hero-greenhouse.jpg" 
                alt="Wilshire Farms Greenhouses"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <motion.div 
                className="absolute bottom-6 left-6 right-6"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.5 }}
              >
                <div className="text-eyebrow text-white/80 mb-2">WILSHIRE FARMS & ORCHARDS</div>
                <h1 className="text-3xl md:text-5xl font-bold text-white mb-3">
                  Grow with the farm.
                </h1>
                <p className="text-white/80 max-w-lg">
                  Partner with us in agricultural investments. From greenhouse peppers to open-field ginger, 
                  be part of Nigeria's growing agricultural revolution.
                </p>
              </motion.div>
            </motion.div>
            
            {/* Status & CTA Cards */}
            <div className="space-y-6">
              {/* Status Card */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.7, delay: 0.3 }}
              >
                <Card className="rounded-[28px] card-shadow card-border h-[220px]">
                  <CardContent className="p-6 flex flex-col justify-center h-full">
                    <div className="text-eyebrow text-[#6E6E6E] mb-3">INVESTMENT STATUS</div>
                    <div className="flex items-center mb-2">
                      <motion.div 
                        className="w-3 h-3 bg-green-500 rounded-full mr-2"
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      />
                      <span className="text-2xl font-bold text-green-600">Currently Open</span>
                    </div>
                    <p className="text-[#6E6E6E] mb-4">
                      Greenhouse D — 8-month Habanero season
                    </p>
                    <div className="text-sm text-[#6E6E6E]">
                      Minimum commitment · 8 months
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
              
              {/* CTA Card */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.7, delay: 0.4 }}
              >
                <Card className="rounded-[28px] card-shadow bg-[#1A1A1A] text-white h-[220px]">
                  <CardContent className="p-6 flex flex-col justify-center h-full">
                    <div className="text-eyebrow text-white/60 mb-3">PARTNER WITH US</div>
                    <h3 className="text-2xl font-bold mb-2">Become a Partner</h3>
                    <p className="text-white/70 text-sm mb-4">
                      Join as a financial, monitoring, or farm partner.
                    </p>
                    <Button 
                      className="bg-[#D9A467] hover:bg-[#C99455] text-white rounded-full w-full"
                      onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                    >
                      Request Details
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Partner Dashboard Section */}
      <section className="py-12 px-4 md:px-8" id="investments">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.6 }}
          >
            <Card className="rounded-[28px] card-shadow card-border overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-[#D9A467]/10 to-transparent p-6 md:p-8">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div>
                    <div className="text-eyebrow text-[#6E6E6E] mb-2">YOUR DASHBOARD</div>
                    <CardTitle className="text-2xl md:text-3xl">
                      Welcome back, {currentPartner.name.split(' ')[0]}
                    </CardTitle>
                  </div>
                  <div className="mt-4 md:mt-0 flex items-center space-x-4">
                    <div className="text-right">
                      <div className="text-sm text-[#6E6E6E]">Total Invested</div>
                      <div className="text-2xl font-bold">
                        ₦{currentPartner.investments.reduce((sum, inv) => sum + inv.amountInvested, 0).toLocaleString()}
                      </div>
                    </div>
                    <div className="w-px h-12 bg-gray-200" />
                    <div className="text-right">
                      <div className="text-sm text-[#6E6E6E]">Expected Returns</div>
                      <div className="text-2xl font-bold text-green-600">
                        ₦{currentPartner.investments.reduce((sum, inv) => sum + inv.expectedReturns, 0).toLocaleString()}
                      </div>
                    </div>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="p-6 md:p-8">
                {/* Partner Stats */}
                <motion.div 
                  className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
                  variants={staggerContainer}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                >
                  <motion.div variants={fadeInUp} className="bg-gray-50 p-4 rounded-xl">
                    <div className="flex items-center text-[#6E6E6E] mb-1">
                      <Users className="w-4 h-4 mr-2" />
                      Partner Type
                    </div>
                    <div className="font-semibold">{currentPartner.type}</div>
                  </motion.div>
                  <motion.div variants={fadeInUp} className="bg-gray-50 p-4 rounded-xl">
                    <div className="flex items-center text-[#6E6E6E] mb-1">
                      <TrendingUp className="w-4 h-4 mr-2" />
                      Active Investments
                    </div>
                    <div className="font-semibold">{currentPartner.investments.length}</div>
                  </motion.div>
                  <motion.div variants={fadeInUp} className="bg-gray-50 p-4 rounded-xl">
                    <div className="flex items-center text-[#6E6E6E] mb-1">
                      <Calendar className="w-4 h-4 mr-2" />
                      Member Since
                    </div>
                    <div className="font-semibold">{currentPartner.joinDate}</div>
                  </motion.div>
                  <motion.div variants={fadeInUp} className="bg-gray-50 p-4 rounded-xl">
                    <div className="flex items-center text-[#6E6E6E] mb-1">
                      <MapPinned className="w-4 h-4 mr-2" />
                      Total Visits
                    </div>
                    <div className="font-semibold">{currentPartner.visitSchedule?.totalVisits || 0}</div>
                  </motion.div>
                </motion.div>
                
                {/* My Investments */}
                <div>
                  <h3 className="text-lg font-bold mb-4">My Investments</h3>
                  <motion.div 
                    className="grid md:grid-cols-2 gap-4"
                    variants={staggerContainer}
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true }}
                  >
                    {currentPartner.investments.map((pi) => {
                      const investment = getInvestmentById(pi.investmentId);
                      if (!investment) return null;
                      return (
                        <motion.div 
                          key={pi.investmentId}
                          variants={fadeInUp}
                          className="flex items-center p-4 bg-gray-50 rounded-xl cursor-pointer hover:bg-gray-100 transition-colors"
                          onClick={() => handleInvestmentClick(investment)}
                          whileHover={{ scale: 1.01 }}
                        >
                          <img 
                            src={investment.coverImage} 
                            alt={investment.name}
                            className="w-20 h-20 rounded-xl object-cover mr-4"
                          />
                          <div className="flex-1">
                            <div className="font-semibold mb-1">{investment.shortName}</div>
                            <div className="text-sm text-[#6E6E6E] mb-2">
                              {pi.percentageShare.toFixed(1)}% share · ₦{pi.amountInvested.toLocaleString()}
                            </div>
                            <StatusBadge status={pi.status} />
                          </div>
                          <ChevronRight className="w-5 h-5 text-[#6E6E6E]" />
                        </motion.div>
                      );
                    })}
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>
      
      {/* All Investments Section */}
      <section className="py-12 px-4 md:px-8" id="seasons">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <motion.div 
            className="flex flex-col md:flex-row md:items-center md:justify-between mb-8"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div>
              <div className="text-eyebrow text-[#6E6E6E] mb-2">ALL OPPORTUNITIES</div>
              <h2 className="text-3xl md:text-4xl font-bold">Investment Seasons</h2>
            </div>
            
            {/* Filters */}
            <div className="mt-4 md:mt-0 flex flex-wrap gap-3">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6E6E6E]" />
                <Input 
                  placeholder="Search investments..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 rounded-full w-48 md:w-64"
                />
              </div>
              
              {/* Status Filter */}
              <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as InvestmentStatus | 'all')}>
                <SelectTrigger className="rounded-full w-40">
                  <Filter className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="Not Started">Not Started</SelectItem>
                  <SelectItem value="Open">Open</SelectItem>
                  <SelectItem value="Closing">Closing</SelectItem>
                  <SelectItem value="Ongoing">Ongoing</SelectItem>
                  <SelectItem value="Closed">Closed</SelectItem>
                </SelectContent>
              </Select>
              
              {/* Partner Filter */}
              <Select value={partnerFilter} onValueChange={(v) => setPartnerFilter(v as 'all' | 'my-investments')}>
                <SelectTrigger className="rounded-full w-44">
                  <Users className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="View" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Investments</SelectItem>
                  <SelectItem value="my-investments">My Investments</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </motion.div>
          
          {/* Investment Cards by Status */}
          {filteredInvestments.length === 0 ? (
            <motion.div 
              className="text-center py-16"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold mb-2">No investments found</h3>
              <p className="text-[#6E6E6E]">Try adjusting your filters</p>
            </motion.div>
          ) : (
            <div className="space-y-12">
              <AnimatePresence mode="wait">
                {statusOrder.map((status, statusIndex) => {
                  const statusInvestments = investmentsByStatus[status];
                  if (statusInvestments.length === 0) return null;
                  
                  return (
                    <motion.div 
                      key={status}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      transition={{ delay: statusIndex * 0.1 }}
                    >
                      <div className="flex items-center mb-4">
                        <StatusBadge status={status} />
                        <span className="ml-3 text-[#6E6E6E]">
                          {statusInvestments.length} season{statusInvestments.length !== 1 ? 's' : ''}
                        </span>
                      </div>
                      <motion.div 
                        className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
                        variants={staggerContainer}
                        initial="hidden"
                        whileInView="visible"
                        viewport={{ once: true, margin: "-50px" }}
                      >
                        {statusInvestments.map((investment) => (
                          <motion.div key={investment.id} variants={fadeInUp}>
                            <InvestmentCard 
                              investment={investment}
                              onClick={() => handleInvestmentClick(investment)}
                              isPartnerInvestment={currentPartner.investments.some(pi => pi.investmentId === investment.id)}
                            />
                          </motion.div>
                        ))}
                      </motion.div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>
      </section>
      
      {/* Contact Section */}
      <div id="contact">
        <ContactSection />
      </div>
      
      {/* Footer */}
      <footer className="bg-[#11130E] text-white py-8 px-4 md:px-8 border-t border-white/10">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center mb-4 md:mb-0">
            <Sprout className="w-6 h-6 text-[#D9A467] mr-2" />
            <span className="font-bold">Wilshire Farms & Orchards</span>
          </div>
          <div className="text-gray-400 text-sm">
            © 2024 Wilshire Farms. All rights reserved.
          </div>
        </div>
      </footer>
      
      {/* Investment Detail Modal */}
      <InvestmentDetailModal 
        investment={selectedInvestment}
        isOpen={isDetailOpen}
        onClose={() => setIsDetailOpen(false)}
      />
    </div>
  );
}

export default App;
