Q: give a deeper analysis of how to conduct Initial Discovery & Portfolio Assessment, list the steps, deliverable artifacts to produce and how to use those artifacts for achieving the listed objectives

---
# Deep Dive: Initial Discovery & Portfolio Assessment for COBOL Modernization

The **Initial Discovery & Portfolio Assessment** phase determines whether the migration succeeds or fails.

This phase creates:

* a complete understanding of the legacy estate,
* technical and business risk visibility,
* modernization prioritization,
* and the factual foundation for cost, timeline, and architecture decisions.

A mature discovery phase is effectively a **forensic analysis of the enterprise system**.

---

# Primary Objectives of Discovery

The discovery phase must achieve these goals:

| Objective                                 | Why It Matters                     |
| ----------------------------------------- | ---------------------------------- |
| Understand the full application landscape | Prevent hidden dependencies        |
| Identify critical business capabilities   | Protect revenue-critical processes |
| Determine migration complexity            | Estimate cost/time accurately      |
| Understand runtime operations             | Preserve production behavior       |
| Extract business rules                    | Preserve functional correctness    |
| Discover data lineage                     | Prevent data corruption            |
| Identify modernization candidates         | Prioritize migration waves         |
| Create migration roadmap                  | Enable phased execution            |
| Build semantic understanding              | Support AI-assisted migration      |

---

# High-Level Discovery Workflow

```text
1. Repository Collection
2. Source Normalization
3. Inventory & Classification
4. Static Analysis
5. Dependency Mapping
6. Runtime Analysis
7. Data Discovery
8. Business Rule Extraction
9. Complexity & Risk Scoring
10. Domain Mapping
11. Modernization Suitability Analysis
12. Migration Wave Planning
13. Discovery Knowledge Graph Creation
14. Executive Assessment Reporting
```

---

# STEP 1 — Repository Collection

# Goal

Acquire every technical artifact involved in the system.

---

# What To Collect

## Source Code

* COBOL
* PL/I
* Assembler
* JCL
* Rexx
* CICS maps
* Easytrieve

---

## Data Definitions

* copybooks
* DDL
* VSAM schemas
* IMS schemas

---

## Runtime Artifacts

* scheduler exports
* batch definitions
* transaction logs
* MQ definitions

---

## Infrastructure Metadata

* LPARs
* queues
* middleware configs
* file transfer configs

---

# Activities

## A. Repository Crawl

Build automated crawlers that:

* recursively scan repositories,
* classify files,
* fingerprint duplicate assets.

---

## B. File Type Detection

Example:

```json
{
  "path": "/payroll/PAY001.cbl",
  "detected_type": "COBOL_PROGRAM",
  "encoding": "EBCDIC",
  "size_bytes": 49281
}
```

---

# Deliverables

## 1. `repository_inventory.json`

Example:

```json
{
  "total_files": 18421,
  "languages": {
    "COBOL": 11231,
    "JCL": 4120,
    "COPYBOOK": 2018
  }
}
```

---

## 2. `artifact_catalog.parquet`

Contains:

* path
* type
* checksum
* owner
* system
* environment
* encoding

---

# How These Artifacts Are Used

| Artifact                  | Usage                  |
| ------------------------- | ---------------------- |
| repository_inventory.json | Scope estimation       |
| artifact_catalog.parquet  | Analysis indexing      |
| checksums                 | Duplicate detection    |
| encoding metadata         | Conversion preparation |

---

# STEP 2 — Source Normalization

# Goal

Convert heterogeneous legacy artifacts into analyzable canonical forms.

---

# Activities

## A. Character Encoding Conversion

Convert:

* EBCDIC
* custom encodings

to:

* UTF-8

---

## B. Line Format Normalization

Handle:

* fixed-column COBOL
* continuation lines
* comments

---

## C. Preprocessing

Expand:

* copybooks
* macros
* includes

---

# Deliverables

## 1. `normalized_sources/`

Canonical source repository.

---

## 2. `normalization_report.json`

Tracks:

* failed conversions
* unsupported encodings
* unresolved includes

---

# Usage

| Artifact             | Purpose          |
| -------------------- | ---------------- |
| normalized_sources   | Input to parsers |
| normalization_report | Risk remediation |

---

# STEP 3 — Inventory & Classification

# Goal

Understand what exists and how assets relate.

---

# Activities

## A. Program Classification

Categorize:

* online transactions
* batch jobs
* utilities
* reports
* ETL programs

---

## B. Business Domain Tagging

Map applications to domains:

* billing
* claims
* payroll
* accounting

---

## C. Environment Mapping

Associate artifacts with:

* dev
* QA
* prod

---

# Deliverables

## 1. `application_registry.json`

Example:

```json
{
  "application": "PAYROLL",
  "domain": "HR",
  "programs": 812,
  "criticality": "HIGH"
}
```

---

## 2. `program_classification.csv`

| Program | Type   | Domain  |
| ------- | ------ | ------- |
| PAY001  | Batch  | Payroll |
| EMPAPI  | Online | HR      |

---

# Usage

| Artifact             | Usage              |
| -------------------- | ------------------ |
| application_registry | Migration planning |
| classification       | Prioritization     |

---

# STEP 4 — Static Code Analysis

# Goal

Extract structural and semantic understanding.

---

# Activities

## A. Parse COBOL ASTs

Build:

* abstract syntax trees
* symbol tables

---

## B. Extract Control Flow

Identify:

* PERFORM chains
* GO TO structures
* CALL hierarchies

---

## C. Extract Data Flow

Trace:

* variable propagation
* DB updates
* file writes

---

# Deliverables

## 1. `ast_repository/`

Serialized ASTs.

---

## 2. `call_graph.json`

Example:

```json
{
  "PAY001": ["TAXCALC", "BENEFITS01"]
}
```

---

## 3. `control_flow_graphs/`

Program CFGs.

---

## 4. `data_lineage_graph.json`

Tracks:

* source fields
* transformations
* outputs

---

# Usage

| Artifact      | Purpose                |
| ------------- | ---------------------- |
| ASTs          | AI/code transformation |
| call graph    | Dependency analysis    |
| CFGs          | Refactoring complexity |
| lineage graph | Data migration         |

---

# STEP 5 — Dependency Mapping

# Goal

Reveal hidden coupling.

---

# Activities

## Analyze Dependencies

### Program-to-program

### Program-to-copybook

### Program-to-table

### Batch-to-file

### MQ-to-consumer

---

# Deliverables

## 1. `dependency_graph.graphml`

Used in:

* Neo4j
* Gephi
* NetworkX

---

## 2. `shared_assets_report.json`

Identifies:

* heavily reused copybooks
* shared DB tables

---

# Usage

| Artifact             | Purpose               |
| -------------------- | --------------------- |
| dependency graph     | Blast-radius analysis |
| shared assets report | Migration sequencing  |

---

# STEP 6 — Runtime & Operational Discovery

# Goal

Understand production behavior.

---

# Activities

## Analyze

### Job Schedules

* nightly jobs
* monthly jobs

### Transaction Volumes

* TPS
* peak windows

### Failure Logs

* retries
* failures

---

# Deliverables

## 1. `runtime_profile.json`

Example:

```json
{
  "batch_window_hours": 6,
  "peak_tps": 840,
  "daily_transactions": 2800000
}
```

---

## 2. `scheduler_dependency_graph.json`

Batch execution ordering.

---

# Usage

| Artifact        | Purpose             |
| --------------- | ------------------- |
| runtime profile | Capacity planning   |
| scheduler graph | Batch modernization |

---

# STEP 7 — Data Discovery

# Goal

Understand enterprise data architecture.

---

# Activities

## Analyze

### DB schemas

### VSAM layouts

### IMS hierarchies

### Flat file formats

---

## Detect

### orphaned tables

### unused fields

### redundant data

---

# Deliverables

## 1. `enterprise_data_dictionary.json`

---

## 2. `schema_mapping_candidates.json`

Example:

```json
{
  "COBOL_FIELD": "EMP-SALARY",
  "PIC": "S9(7)V99 COMP-3",
  "SuggestedJavaType": "BigDecimal"
}
```

---

## 3. `data_quality_report.json`

---

# Usage

| Artifact        | Purpose                 |
| --------------- | ----------------------- |
| data dictionary | Migration schema design |
| type mappings   | Code generation         |
| quality report  | Cleansing strategy      |

---

# STEP 8 — Business Rule Extraction

# Goal

Recover institutional knowledge buried in code.

---

# Activities

## Detect

### calculations

### validations

### pricing rules

### eligibility logic

---

## Techniques

### NLP over comments

### pattern matching

### LLM semantic extraction

### symbolic execution

---

# Deliverables

## 1. `business_rules_catalog.json`

Example:

```json
{
  "rule_id": "RULE_88",
  "description": "Apply late fee after 30 days"
}
```

---

## 2. `decision_tables.xlsx`

---

## 3. `rule_traceability_map.json`

Links:

* rules
* programs
* DB fields

---

# Usage

| Artifact         | Purpose                 |
| ---------------- | ----------------------- |
| rules catalog    | Functional preservation |
| traceability map | Validation/testing      |

---

# STEP 9 — Complexity & Risk Analysis

# Goal

Quantify modernization difficulty.

---

# Metrics

## Code Metrics

* LOC
* cyclomatic complexity
* nesting depth

---

## Operational Metrics

* runtime criticality
* SLA sensitivity

---

## Business Metrics

* regulatory importance
* revenue dependency

---

# Deliverables

## 1. `complexity_scores.csv`

---

## 2. `risk_assessment.json`

Example:

```json
{
  "program": "PAY001",
  "risk": "HIGH",
  "reasons": [
    "High coupling",
    "Critical payroll logic"
  ]
}
```

---

## 3. `modernization_readiness_report.pdf`

---

# Usage

| Artifact          | Purpose            |
| ----------------- | ------------------ |
| complexity scores | Estimation         |
| risk report       | Sequencing         |
| readiness report  | Executive approval |

---

# STEP 10 — Domain Mapping

# Goal

Prepare for microservice/domain decomposition.

---

# Activities

Map systems into:

* bounded contexts
* business capabilities

---

# Deliverables

## 1. `domain_model.json`

---

## 2. `capability_matrix.xlsx`

| Capability | Systems | Criticality |
| ---------- | ------- | ----------- |
| Payroll    | PAY001  | HIGH        |

---

# Usage

| Artifact          | Purpose               |
| ----------------- | --------------------- |
| domain model      | Service decomposition |
| capability matrix | Wave planning         |

---

# STEP 11 — Migration Suitability Analysis

# Goal

Determine HOW each component should migrate.

---

# Categories

| Strategy  | Candidate Type         |
| --------- | ---------------------- |
| Rehost    | stable utility systems |
| Translate | medium complexity      |
| Rewrite   | highly coupled logic   |
| Retire    | dead systems           |

---

# Deliverables

## 1. `migration_strategy_matrix.json`

---

## 2. `retirement_candidates.csv`

---

# Usage

| Artifact        | Purpose         |
| --------------- | --------------- |
| strategy matrix | Budgeting       |
| retirement list | Scope reduction |

---

# STEP 12 — Migration Wave Planning

# Goal

Sequence modernization safely.

---

# Activities

Prioritize:

* low-risk first
* low-coupling first
* domain-by-domain

---

# Deliverables

## 1. `migration_wave_plan.xlsx`

Example:

| Wave   | Systems   |
| ------ | --------- |
| Wave 1 | Reporting |
| Wave 2 | Billing   |

---

## 2. `dependency_constraints.json`

---

# Usage

| Artifact    | Purpose           |
| ----------- | ----------------- |
| wave plan   | Program execution |
| constraints | Release planning  |

---

# STEP 13 — Discovery Knowledge Graph

# Goal

Create a unified enterprise semantic graph.

---

# Nodes

* programs
* tables
* fields
* jobs
* APIs
* rules
* domains

---

# Edges

* CALLS
* WRITES
* READS
* DEPENDS_ON

---

# Deliverables

## 1. `enterprise_knowledge_graph.neo4j`

---

## 2. `graph_schema.json`

---

# Usage

| Artifact        | Purpose               |
| --------------- | --------------------- |
| knowledge graph | AI-assisted migration |
| graph schema    | Query tooling         |

---

# STEP 14 — Executive Assessment & Roadmap

# Goal

Convert technical findings into business decisions.

---

# Deliverables

## 1. `executive_summary.pptx`

Contains:

* risk
* cost
* timeline
* staffing

---

## 2. `migration_roadmap.md`

---

## 3. `estimated_effort_model.xlsx`

---

# Usage

| Artifact          | Purpose             |
| ----------------- | ------------------- |
| executive summary | Stakeholder buy-in  |
| roadmap           | Delivery governance |
| effort model      | Budget approval     |

---

# Most Important Discovery Outputs

These are the highest-value artifacts:

| Artifact                  | Why Critical             |
| ------------------------- | ------------------------ |
| dependency_graph          | prevents hidden failures |
| business_rules_catalog    | preserves behavior       |
| data_lineage_graph        | ensures data correctness |
| runtime_profile           | preserves SLAs           |
| migration_strategy_matrix | controls scope           |
| knowledge_graph           | enables AI automation    |

---

# Discovery Anti-Patterns

# 1. Inventory Without Runtime Analysis

Static code alone is insufficient.

---

# 2. Ignoring Copybooks

Copybooks often define enterprise-wide data contracts.

---

# 3. Big-Bang Planning Too Early

You need dependency analysis first.

---

# 4. No Business Rule Extraction

This is the #1 cause of failed rewrites.

---

# 5. Underestimating Batch Complexity

Batch orchestration is often harder than COBOL syntax.

---

# Modern AI-Assisted Discovery Architecture

Modern platforms increasingly use:

* LLM semantic extraction
* graph databases
* vector embeddings
* code knowledge graphs
* retrieval-augmented generation
* autonomous analysis agents

to automate:

* rule extraction,
* lineage generation,
* impact analysis,
* and migration planning.

This is becoming the foundation of next-generation modernization platforms.

