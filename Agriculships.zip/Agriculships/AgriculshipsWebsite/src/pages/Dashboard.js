// src/pages/Dashboard.jsx
import React from 'react'

export default function Dashboard(){
  // Simple mock dashboard view
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <h2 className="text-2xl font-bold">Investor Dashboard (Mock)</h2>
        <p className="mt-2 text-gray-600">This is a mock dashboard — in a real app you'd see portfolio holdings, performance and documents here.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white rounded shadow p-6">
            <div className="text-sm text-gray-500">Portfolio value</div>
            <div className="text-2xl font-bold">$120,450</div>
          </div>
          <div className="bg-white rounded shadow p-6">
            <div className="text-sm text-gray-500">Current yield</div>
            <div className="text-2xl font-bold">8.2%</div>
          </div>
          <div className="bg-white rounded shadow p-6">
            <div className="text-sm text-gray-500">Active offerings</div>
            <div className="text-2xl font-bold">3</div>
          </div>
        </div>

        <div className="mt-8 bg-white rounded shadow p-6">
          <h4 className="font-semibold">Recent documents</h4>
          <ul className="mt-3 text-sm text-gray-600">
            <li>• Offering Memorandum — Sweet Peppers (PDF)</li>
            <li>• Subscription Agreement — Cocoa (PDF)</li>
          </ul>
        </div>
      </div>
    </div>
  )
}