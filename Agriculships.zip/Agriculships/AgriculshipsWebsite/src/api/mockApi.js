// src/api/mockApi.js
export const mockDelay = (ms=600) => new Promise(res => setTimeout(res, ms))

export async function fetchInvestmentOpportunities(){
  await mockDelay(700)
  return [
    {
      id: 'inv-pepper-001',
      crop: 'Sweet Peppers',
      location: 'Mabana, Country X',
      minInvestment: 25000,
      targetIrr: 0.08,
      termYears: 3,
      description: 'High-yield greenhouse plots focused on specialty sweet peppers for export markets. Structured as single-purpose LLCs with experienced local operators.',
      availableShares: 1200,
      image: 'https://images.unsplash.com/photo-1524594154905-8337d8e2d63e?q=80&w=1200&auto=format&fit=crop'
    },
    {
      id: 'inv-hab-002',
      crop: 'Habanero',
      location: 'Coastal Region, Country Y',
      minInvestment: 30000,
      targetIrr: 0.10,
      termYears: 4,
      description: 'Drought-tolerant varieties on leased farmland with guaranteed offtake agreements. Managed with agronomist-led production plans.',
      availableShares: 800,
      image: 'https://images.unsplash.com/photo-1506806732259-39c2d0268443?q=80&w=1200&auto=format&fit=crop'
    },
    {
      id: 'inv-cocoa-003',
      crop: 'Cocoa',
      location: 'Rainbelt, Country Z',
      minInvestment: 50000,
      targetIrr: 0.09,
      termYears: 6,
      description: 'Long-term investment in rehabilitated cocoa estates with certified sustainable practices and farmer partnership programs.',
      availableShares: 600,
      image: 'https://images.unsplash.com/photo-1501004318641-b39e6451bec6?q=80&w=1200&auto=format&fit=crop'
    },
    {
      id: 'inv-palm-004',
      crop: 'Oil Palm',
      location: 'Tropical Lowlands, Country A',
      minInvestment: 75000,
      targetIrr: 0.07,
      termYears: 8,
      description: 'Investment-grade plantations under careful ESG screening. Revenue sources include rental income and yield-linked profit-sharing.',
      availableShares: 400,
      image: 'https://images.unsplash.com/photo-1519681393784-d120267933ba?q=80&w=1200&auto=format&fit=crop'
    },
    {
      id: 'inv-cassava-005',
      crop: 'Cassava',
      location: 'Savannah Region, Country B',
      minInvestment: 20000,
      targetIrr: 0.06,
      termYears: 3,
      description: 'Fast-cycling tuber plots with integrated processing options for increased value capture.',
      availableShares: 1500,
      image: 'https://images.unsplash.com/photo-1509343256512-2f8f4b1d2b8f?q=80&w=1200&auto=format&fit=crop'
    }
  ]
}