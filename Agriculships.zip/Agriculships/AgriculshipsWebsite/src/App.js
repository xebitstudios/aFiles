// src/App.jsx
import React, { useEffect, useState } from 'react'
import Header from './components/Header'
import Hero from './components/Hero'
import HowItWorks from './components/HowItWorks'
import Opportunities from './components/Opportunities'
import Team from './components/Team'
import FAQ from './components/FAQ'
import Footer from './components/Footer'
import AccreditationModal from './components/AccreditationModal'
import { fetchInvestmentOpportunities } from './api/mockApi'

export default function App(){
  const [opportunities, setOpportunities] = useState([])
  const [loading, setLoading] = useState(true)
  const [showAccreditation, setShowAccreditation] = useState(false)
  const [toast, setToast] = useState(null)

  useEffect(()=>{
    let cancelled = false
    async function load(){
      try{
        const data = await fetchInvestmentOpportunities()
        if (!cancelled) setOpportunities(data)
      }catch(err){
        console.error(err)
      }finally{
        if (!cancelled) setLoading(false)
      }
    }
    load()
    return ()=>{ cancelled = true }
  },[])

  function handleExpressInterest(op){
    setToast(`Interest recorded for ${op.crop}. Our capital team will contact you.`)
    setTimeout(()=>setToast(null), 5000)
  }

  return (
    <div className="min-h-screen font-sans text-gray-800">
      <Header onOpenAccreditation={()=>setShowAccreditation(true)} />
      <main>
        <Hero onOpenAccreditation={()=>setShowAccreditation(true)} />
        <HowItWorks />
        {loading ? (
          <div className="max-w-7xl mx-auto p-8 text-center text-gray-500">Loading opportunities...</div>
        ) : (
          <Opportunities opportunities={opportunities} onExpressInterest={handleExpressInterest} />
        )}
        <Team />
        <FAQ />
      </main>
      <Footer />
      {showAccreditation && <AccreditationModal onClose={()=>setShowAccreditation(false)} />}
      {toast && (
        <div className="fixed left-1/2 transform -translate-x-1/2 bottom-6 bg-emerald-700 text-white px-4 py-2 rounded shadow">{toast}</div>
      )}
    </div>
  )
}