// src/components/FAQ.jsx
import React from 'react'

export default function FAQ(){
  const faqs = [
    { q: 'Who can invest?', a: 'Offerings are available only to accredited investors as defined by applicable securities laws.' },
    { q: 'How are farms sourced?', a: 'We use a multi-stage sourcing and due-diligence process including technical, legal, financial and ESG assessments.' },
    { q: 'How do I get returns?', a: 'Returns may come from rental income, profit-sharing on crop sales, and potential property appreciation, depending on the offering.' },
    { q: 'What fees apply?', a: 'Fees include acquisition costs, management fees, and platform fees. Specifics are disclosed in each offering memorandum.' }
  ]

  return (
    <section id="faq" className="max-w-7xl mx-auto px-6 py-16">
      <h3 className="text-3xl font-bold mb-6">FAQ</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {faqs.map((f,i)=> (
          <div key={i} className="bg-white rounded-lg shadow p-6">
            <div className="font-medium">{f.q}</div>
            <div className="mt-2 text-sm text-gray-600">{f.a}</div>
          </div>
        ))}
      </div>
    </section>
  )
}