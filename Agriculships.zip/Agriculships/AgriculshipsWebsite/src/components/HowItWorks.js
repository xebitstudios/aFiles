// src/components/HowItWorks.jsx
import React from 'react'

export default function HowItWorks(){
  const steps = [
    { title: 'Sourcing & Due Diligence', desc: 'We identify investment-grade farmland and perform technical, legal, and ESG due diligence before acquisition or leasing.' },
    { title: 'Structured Ownership', desc: 'Each farm is held in a single-purpose entity (e.g., LLC) to isolate liabilities and deliver transparent economics.' },
    { title: 'Operational Management', desc: 'We partner with local farmers and managers to run day-to-day operations, procurement, and reporting.' },
    { title: 'Investor Returns', desc: 'Investors earn from rental income, profit-sharing, and potential property appreciation depending on the offering.' }
  ]

  return (
    <section id="how" className="max-w-7xl mx-auto px-6 py-16">
      <h3 className="text-3xl font-bold mb-6">How it works</h3>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {steps.map((s, i) => (
          <div key={i} className="bg-white rounded-lg shadow p-6">
            <div className="w-10 h-10 rounded-md bg-emerald-700 text-white flex items-center justify-center font-semibold">{i+1}</div>
            <h4 className="mt-4 font-semibold">{s.title}</h4>
            <p className="mt-2 text-sm text-gray-600">{s.desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}