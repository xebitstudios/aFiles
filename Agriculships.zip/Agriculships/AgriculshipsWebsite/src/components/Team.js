// src/components/Team.jsx
import React from 'react'

export default function Team(){
  const members = [
    { name: 'Aisha Bello', role: 'Founder & CEO' },
    { name: 'Marc Thompson', role: 'Head of Investments' },
    { name: 'Dr. Nkem Okoye', role: 'Lead Agronomist' }
  ]

  return (
    <section id="team" className="max-w-7xl mx-auto px-6 py-16">
      <h3 className="text-3xl font-bold mb-6">Our team</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {members.map(m => (
          <div key={m.name} className="bg-white rounded-lg shadow p-6 text-center">
            <div className="w-20 h-20 rounded-full mx-auto bg-gray-200 flex items-center justify-center font-bold text-xl">{m.name.split(' ').map(n=>n[0]).join('')}</div>
            <h4 className="mt-4 font-semibold">{m.name}</h4>
            <div className="text-sm text-gray-500">{m.role}</div>
          </div>
        ))}
      </div>
    </section>
  )
}