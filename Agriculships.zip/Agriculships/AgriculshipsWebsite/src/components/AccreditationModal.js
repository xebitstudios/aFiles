// src/components/AccreditationModal.jsx
import React from 'react'

export default function AccreditationModal({ onClose }){
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative bg-white rounded-lg shadow-lg max-w-2xl w-full p-6">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-semibold">Accredited investor information</h3>
            <p className="mt-2 text-sm text-gray-600">To participate in our offerings you must qualify as an accredited investor under applicable rules. Common criteria include income or net worth thresholds — please consult your legal or tax advisor.</p>
          </div>
          <button onClick={onClose} className="text-gray-500">✕</button>
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-gray-50 rounded p-4">
            <div className="font-semibold">Individual</div>
            <ul className="text-sm text-gray-600 mt-2 space-y-1">
              <li>• Income of $200,000+ (individual) or $300,000+ (joint) in last 2 years</li>
              <li>• OR net worth over $1M (excluding primary residence)</li>
            </ul>
          </div>
          <div className="bg-gray-50 rounded p-4">
            <div className="font-semibold">Entities</div>
            <div className="text-sm text-gray-600 mt-2">Certain entities (e.g., banks, insurance companies, large trusts) may qualify as accredited investors. Check rules for specifics.</div>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3">
          <button onClick={onClose} className="px-4 py-2 border rounded">Close</button>
          <a href="/contact" className="px-4 py-2 bg-emerald-700 text-white rounded">Contact us</a>
        </div>
      </div>
    </div>
  )
}