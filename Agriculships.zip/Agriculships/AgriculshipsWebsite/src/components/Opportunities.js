// src/components/Opportunities.jsx
import React from 'react'

export default function Opportunities({ opportunities, onExpressInterest }){
  return (
    <section id="opportunities" className="max-w-7xl mx-auto px-6 py-16">
      <div className="flex items-center justify-between">
        <h3 className="text-3xl font-bold">Current investment opportunities</h3>
        <div className="text-sm text-gray-500">Minimums and terms vary by offering</div>
      </div>

      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {opportunities.map(op => (
          <div key={op.id} className="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden">
            <img src={op.image} alt={op.crop} className="w-full h-44 object-cover" />
            <div className="p-5">
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="text-lg font-semibold">{op.crop}</h4>
                  <div className="text-sm text-gray-500">{op.location}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm text-gray-500">Min</div>
                  <div className="text-xl font-bold text-emerald-700">${op.minInvestment.toLocaleString()}</div>
                </div>
              </div>

              <p className="mt-3 text-sm text-gray-700">{op.description}</p>

              <div className="mt-4 flex items-center justify-between">
                <div className="text-sm text-gray-500">Target IRR: <span className="font-medium text-gray-800">{(op.targetIrr*100).toFixed(0)}%</span></div>
                <div className="flex gap-2">
                  <button onClick={()=>onExpressInterest(op)} className="px-4 py-2 bg-emerald-700 text-white rounded-md text-sm">Express interest</button>
                  <a href={`/offerings/${op.id}`} className="px-3 py-2 border rounded-md text-sm">Details</a>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}