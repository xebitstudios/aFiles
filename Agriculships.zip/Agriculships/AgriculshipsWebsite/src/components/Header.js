// src/components/Header.jsx
import React from 'react'
import { Link } from 'react-router-dom'

export default function Header({ onOpenAccreditation }){
  return (
    <header className="bg-white shadow sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-md bg-emerald-700 flex items-center justify-center text-white font-bold">A</div>
          <div>
            <div className="text-lg font-semibold">Agriculships Capital</div>
            <div className="text-xs text-gray-500">Curated farmland investments</div>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-6 text-sm">
          <a href="#how" className="hover:text-emerald-700">How it works</a>
          <a href="#opportunities" className="hover:text-emerald-700">Opportunities</a>
          <a href="#team" className="hover:text-emerald-700">Team</a>
          <a href="#faq" className="hover:text-emerald-700">FAQ</a>
        </nav>

        <div className="flex items-center gap-3">
          <button onClick={onOpenAccreditation} className="px-4 py-2 border border-emerald-700 text-emerald-700 rounded-md text-sm">Accreditation</button>
          <Link to="/dashboard" className="px-4 py-2 bg-emerald-700 text-white rounded-md text-sm">Investor Dashboard</Link>
        </div>
      </div>
    </header>
  )
}