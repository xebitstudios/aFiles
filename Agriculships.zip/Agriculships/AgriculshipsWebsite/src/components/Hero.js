// src/components/Hero.jsx
import React from 'react'

export default function Hero({ onOpenAccreditation }){
  return (
    <section className="relative bg-gray-50">
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1501004318641-b39e6451bec6?q=80&w=1600')] bg-cover bg-center opacity-20" />
      <div className="relative max-w-7xl mx-auto px-6 py-20 grid lg:grid-cols-2 gap-8">
        <div className="bg-white/80 backdrop-blur rounded-lg p-8 shadow">
          <h1 className="text-3xl md:text-4xl font-extrabold text-gray-900">Invest directly in farmland & crop projects</h1>
          <p className="mt-4 text-gray-700">We source, structure and manage farmland investments — enabling accredited investors to buy shares in single-purpose entities and earn from rent and property appreciation.</p>

          <div className="mt-6 flex gap-3">
            <button onClick={onOpenAccreditation} className="px-5 py-3 bg-emerald-700 text-white rounded-md">Am I accredited?</button>
            <a href="#opportunities" className="px-5 py-3 border rounded-md">View opportunities</a>
          </div>

          <p className="mt-4 text-xs text-gray-500">Not an offering. Investments carry risk. Must be accredited to participate.</p>
        </div>

        <div className="flex flex-col gap-4">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-sm text-gray-500">Sourced farms</div>
            <div className="text-2xl font-bold">45+</div>
            <div className="text-sm text-gray-500 mt-1">ESG screened & investment-grade</div>
          </div>
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-sm text-gray-500">Active partnerships</div>
            <div className="text-2xl font-bold">30+</div>
            <div className="text-sm text-gray-500 mt-1">Local farmer partnerships</div>
          </div>
        </div>
      </div>
    </section>
  )
}