﻿namespace SharedConstructs;

public abstract class AggregationResponseTarget
{
    
}