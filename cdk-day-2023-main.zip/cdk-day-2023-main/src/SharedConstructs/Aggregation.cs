﻿namespace SharedConstructs;

public abstract class Aggregation
{
    public abstract string AggregationArn { get; }
}