# CDK Day 2023

Code samples from CDK Day 2023.

## Prerequisites

- .NET 6
- AWS CDK

## Deploy

```
cdk deploy
```
